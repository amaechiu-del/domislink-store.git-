# 50 Ways to Generate AC Electricity at No Fuel Cost
### A DomisLink practical guide

**Read this first — the honest physics.** There is no "free energy" machine: nothing produces electricity from nothing, and any device claiming to (perpetual motion / "over-unity") is a scam. What *is* real and what this guide means by **"free"** is **no fuel cost** — harnessing energy that is already around you (sun, wind, water, heat, motion) so you pay for equipment once, not for diesel or petrol forever.

**Why AC, and how you get it.** Alternating current is produced two ways: (1) directly, by spinning an **alternator** (any rotating source — wind, water, an engine — turns a magnet past coils and makes AC); or (2) from a DC source (solar panels, batteries, fuel cells) passed through an **inverter**, which converts DC to clean sine-wave AC. Both routes appear below.

> ⚠️ **Safety:** mains-voltage AC and grid connection are dangerous and regulated. Have a qualified electrician install and certify anything that feeds sockets or ties to the grid, and follow your national regulations (in Nigeria, NEMSA / your DisCo).

---

## A. Wind → alternator (AC directly)
1. **Horizontal-axis wind turbine** — classic propeller turning an alternator; best with steady wind.
2. **Vertical-axis Savonius turbine** — drag-type, handles gusty/urban wind, simple to build.
3. **Vertical-axis Darrieus turbine** — lift-type, higher efficiency at speed.
4. **Rooftop micro-wind turbine** — small alternator for a single home.
5. **Ducted / shrouded wind turbine** — a funnel accelerates wind onto a smaller rotor.
6. **Building-edge wind acceleration** — mount turbines where wind speeds up over a roofline.
7. **Highway/roadside wind capture** — vertical turbines driven by the draft of passing vehicles.
8. **Airborne / kite wind generator** — a tethered kite drives a ground alternator at altitude winds.

## B. Water → alternator (AC directly)
9. **Micro-hydro run-of-river turbine** — a stream's flow spins an alternator; superb where water is constant.
10. **Pico-hydro (<5 kW)** — small village/household hydro on a creek.
11. **Overshot/undershot water wheel + alternator** — low-tech, durable.
12. **In-pipe hydro turbine** — recover energy inside pressurised water mains.
13. **Rainwater downpipe turbine** — small generation from roof runoff.
14. **Tidal stream turbine** — coastal currents drive an alternator.
15. **Wave-motion generator** — buoy movement drives a rotary or linear alternator.
16. **Canal / irrigation-channel turbine** — steady low-head flow.

## C. Solar → inverter (DC made into AC)
17. **PV panels + grid-tie inverter** — sell/offset to the grid.
18. **PV panels + off-grid inverter + batteries** — standalone home AC (common in Nigeria).
19. **Hybrid inverter system** — PV + battery + grid/generator switching automatically.
20. **Concentrated solar power (CSP)** — mirrors boil fluid to spin a steam turbine + alternator.
21. **Solar-dish Stirling engine + alternator** — concentrated heat drives an engine.
22. **Solar updraft tower** — sun heats air under a canopy; rising air spins a turbine.

## D. Heat & gas → engine/turbine + alternator
23. **Biogas digester + gas genset** — kitchen/farm waste makes methane that runs an alternator.
24. **Wood-gas (gasifier) generator** — biomass gas powers an engine-alternator.
25. **Geothermal steam turbine** — earth heat spins a turbine + alternator.
26. **Organic Rankine Cycle (ORC) on industrial waste heat** — low-grade heat boils a fluid to drive a turbine.
27. **Waste-heat recovery from engines/exhaust** — ORC or steam loop on existing machinery.
28. **Landfill / sewage gas genset** — captured gas runs an alternator.
29. **Concentrated-solar + ORC** — solar heat into an ORC turbine for smaller scales.
30. **Cookstove thermoelectric + inverter** — heat→DC via TEG, then inverter to AC (small loads).

## E. Human, animal & traffic kinetic energy
31. **Pedal / bicycle alternator** — exercise produces usable AC via inverter or direct alternator.
32. **Treadmill or rowing-machine generator** — capture gym effort.
33. **Hand-crank alternator** — emergency lighting and charging.
34. **Animal-powered rotary drive + alternator** — a traditional turning post geared to a generator.
35. **Footstep / floor-tile generators** — electromagnetic tiles in busy walkways (inverter to AC).
36. **Speed-bump generators** — vehicle weight drives a generator at junctions.
37. **Turnstile / door generators** — capture motion in high-traffic entrances.
38. **Playground / merry-go-round generator** — children's play turns an alternator.

## F. Marine & ambient flow
39. **Ocean thermal energy conversion (OTEC)** — temperature difference drives a turbine.
40. **Salinity-gradient (osmotic) power** — river-meets-sea energy.
41. **Tidal lagoon / barrage turbine** — captured tide drives turbines on the ebb and flow.
42. **River kinetic turbine (no dam)** — free-flow underwater rotor.
43. **Floating offshore wind** — turbines on floating platforms over deep water.
44. **Hybrid wave + wind buoys** — combined capture on one platform.

## G. Conversion, storage & smoothing (turning any source into steady AC)
45. **Pure sine-wave inverter on any DC source** — batteries, PV or fuel cells → clean AC.
46. **DC microgrid + central inverter** — collect many DC sources, output one AC supply.
47. **Flywheel + alternator** — store rotational energy to smooth gusty wind/hydro into steady AC.
48. **Grid-forming inverter for off-grid AC** — creates a stable AC "grid" without the utility.
49. **Hybrid solar + wind + inverter** — complementary sources feed one inverter for fewer gaps.
50. **Hydrogen fuel cell + inverter** — fuel cell makes DC (from hydrogen you can produce with surplus solar/wind), inverter makes AC.

---

### Choosing for Nigeria
For most homes and small businesses, **#18 (solar + off-grid inverter + batteries)** and **#23 (biogas genset)** are the most practical no-fuel-cost AC sources today; **#9–10 (micro/pico-hydro)** is excellent where there is a reliable stream. Wind (#1–4) suits specific coastal and elevated sites.

*This guide explains principles for education and planning. Sizing, wiring, protection and any grid connection must be designed and certified by a qualified electrical engineer to your national standards.*

© DomisLink International Services Ltd · webstore.domislink.com
